# Root
> <b>Isso não é como o root real do linux</b>e usos do termux. Esta ferramenta também ajudará você a obter a aparência do Kali-Linux no seu termux com acesso root.<br><br>

<centre>
<img src="https://github.com/adarshaddee/root/blob/main/images/Img2.jpg" alt="root termux" title="root termux" width="100%" />
</centre>

# Apoio, suporte
[![Watch the video](https://img.youtube.com/vi/LAJfrWPm4NU/maxresdefault.jpg)](https://www.youtube.com/watch?v=LAJfrWPm4NU)
> olá, você pode se inscrever <a href="https://m.youtube.com/@Termuxhacker131">Termux Hacker</a> para vídeos interessantes OU siga <a href="https://muxhacke.blogspot.com"> O Termux Hacker </a>Site do Blogger para blogs interessantes. Procurar <a href="https://m.youtube.com/@alvarinholuis">"Alvarinho Luis"</a> subrescreva-se para mais videos. 

# Privilégios falsos de root
Esta ferramenta ajuda você a acessar os falsos privilégios de root no termux. Para acessar os falsos privilégios de root no termux, basta digitar <pre>fakeroot</pre> em termux. E aqui está, agora você obteve o falso acesso de privilégios de root no termux..

# Privilégios Reais do root
Esta ferramenta também ajuda a acessar os privilégios reais de root no termux. O que é mais poderoso e mais forte do que privilégios de root falsos. Para acessar o root  real privilégios apenas digite <pre>root</pre> no teu termux.E aqui está, você tem acesso ao verdadeiro privilégio de root no termux sem fazer root no seu dispositivo apenas com esta ferramenta (Root)

# Instalação
<pre>pkg update && pkg upgrade -y</pre>
<pre>pkg install git -y</pre>
<pre>git clone https://github.com/Alvax12/rootfalso</pre>
<pre>cd rootfalso</pre>
<pre>chmod +x main</pre>
<pre>./main</pre>

# Complementos
Podes usar <pre>fish</pre> o comando para deixar o termux mais atraente.<br><br>

# Instalação de uma linha
<pre>pkg  update && pkg  upgrade -y && pkg  install git -y && git clone https://github.com/adarshaddee/root.git</pre>

# Desistalar
Você pode desinstalar o root com os seguintes comandos mostrados aqui:
<pre>cd rootfalso</pre>
<pre>chmod +x uninstall.sh</pre>
<pre>./uninstall.sh</pre>

# Copyright
<pre>© Os créditos de copyright vão para Alvarinho Luis. Esta ferramenta é uma ferramenta pública que qualquer pessoa pode usar esta ferramenta.</pre>
